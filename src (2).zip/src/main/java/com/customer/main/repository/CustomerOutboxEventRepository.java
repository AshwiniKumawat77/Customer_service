package com.customer.main.repository;

public interface CustomerOutboxEventRepository {

}
