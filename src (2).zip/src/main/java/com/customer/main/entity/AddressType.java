package com.customer.main.entity;

public enum AddressType {
	 CURRENT,
	 PERMANENT
}
